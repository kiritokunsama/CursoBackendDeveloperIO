package one.digitalinnovation.finals;

public class Gamer {

    public String keyboard() {
        return "Keyboard Gamer!";
    }

    public final String mouse() {
        return "Mouse Gamer!";
    }



}
