INSERT INTO pais (id, nome, nome_pt, sigla, bacen) VALUES (1, 'Brazil', 'Brasil', 'BR', 1058);

INSERT INTO estado (id, nome, uf, ibge, pais, ddd) VALUES (26, 'São Paulo', 'SP', 35, 1, '[11,12,13,14,15,16,17,18,19]');

INSERT INTO cidade (id, nome, uf, ibge, lat_lon) VALUES (4929, 'Ibaté', 26,	3519303, '(-21.958400726318359,-47.988201141357422)');
INSERT INTO cidade (id, nome, uf, ibge, lat_lon) VALUES (5254, 'São Carlos', 26, 3548906, '(-22.017400741577148,-47.886001586914063)');